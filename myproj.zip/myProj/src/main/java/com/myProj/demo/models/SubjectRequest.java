package com.myProj.demo.models;


import com.myProj.demo.entity.Professor;

import java.io.Serializable;

public class SubjectRequest implements Serializable {
   //@JsonIgnore
    private int id;
    private String name;
    private Professor professorId;
    public SubjectRequest(){

    }

    public SubjectRequest(String name) {
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Professor getProfessorId() {
        return professorId;
    }

    public void setProfessorId(Professor professorId) {
        this.professorId = professorId;
    }

}
