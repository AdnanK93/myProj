package com.myProj.demo.controller;

import com.myProj.demo.models.SubjectRequest;
import com.myProj.demo.models.SubjectResponse;
import com.myProj.demo.service.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/subject")
public class SubjectController {
    @Autowired
    SubjectService subjectService;

    @PostMapping(value = "/create-subject")
    public SubjectResponse create(@RequestBody SubjectRequest subjectRequest) {
        return subjectService.create(subjectRequest);
    }

    @PostMapping(value = "/{subId}/{profId}")
    public SubjectResponse addPtoSub(@PathVariable int subId, @PathVariable int profId) {
        return subjectService.addPTosub(subId, profId);
    }

    @GetMapping(value = "/{subId}")
    public SubjectResponse find(@PathVariable int subId) {
        return subjectService.getSub(subId);
    }

    @DeleteMapping(value = "/{subId}")
    public String delete(@PathVariable int subId) {
        return subjectService.delete(subId);
    }

    @PutMapping(value = "/{subId}")
    public SubjectResponse update(@PathVariable int subId, @RequestBody SubjectRequest subjectRequest) {
        return subjectService.update(subId, subjectRequest);
    }
}
