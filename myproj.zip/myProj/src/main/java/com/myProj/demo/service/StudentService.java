package com.myProj.demo.service;

import com.myProj.demo.entity.Student;
import com.myProj.demo.models.StudentRequest;
import com.myProj.demo.models.StudentResponse;
import org.springframework.stereotype.Service;

@Service
public interface StudentService {
    StudentResponse create(StudentRequest studentRequest);

    String delete(int studId);

    boolean existById(int studId);

    StudentResponse getById(int studId);

    StudentResponse update(int studId, StudentRequest studentRequest);
}
