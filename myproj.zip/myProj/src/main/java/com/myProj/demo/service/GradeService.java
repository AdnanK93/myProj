package com.myProj.demo.service;

import com.myProj.demo.models.GradeCreateReq;
import com.myProj.demo.models.GradeRequest;
import com.myProj.demo.models.GradeResponse;

public interface GradeService {
    GradeResponse create(GradeCreateReq gradeCreateReq);

    GradeResponse getGr(int grId);

    String delete(int grId);

    GradeResponse update(int grId, GradeRequest gradeRequest);
}
