package com.myProj.demo.service;

import com.myProj.demo.Repository.ProfessorRep;
import com.myProj.demo.Repository.SubjectRep;
import com.myProj.demo.controller.ErrorException;
import com.myProj.demo.entity.Professor;
import com.myProj.demo.entity.Subject;
import com.myProj.demo.mapper.SubjectMapper;
import com.myProj.demo.models.SubjectRequest;
import com.myProj.demo.models.SubjectResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubjectServiceImpl implements SubjectService {
    @Autowired
    SubjectRep subjectDAO;
    @Autowired
    SubjectMapper subjectMapper;
    @Autowired
    ProfessorRep professorDAO;

    @Override
    public SubjectResponse create(SubjectRequest subjectRequest) {
        Subject subject = new Subject();
        subject = subjectMapper.reqToSubj(subject, subjectRequest);
        subjectDAO.save(subject);
        return subjectMapper.reqToRes(subjectRequest);
    }

    @Override
    public SubjectResponse getSub(int subId) {

        return subjectMapper.subToRes(subjectDAO.getOne(subId));
    }

    @Override
    public SubjectResponse addPTosub(int subId, int profId) {

        if (!subjectDAO.existsById(subId)) {
            throw new ErrorException("Subject dont exist");
        }
        if (!professorDAO.existsById(profId)) {
            throw new ErrorException("Professor dont exist");
        }
        Professor professor = professorDAO.getOne(profId);

        Subject subject = subjectDAO.getOne(subId);
        subject.setProfessorId(professor);
        subjectDAO.save(subject);
        return subjectMapper.subToRes(subject);
    }

    @Override
    public String delete(int subId) {
        if (!subjectDAO.existsById(subId)) {
            throw new ErrorException("Subject with id " + subId + " dont exist");
        }
        return "Subject with id " + subId + " deleted.";
    }

    @Override
    public SubjectResponse update(int subId, SubjectRequest subjectRequest) {
        if (!subjectDAO.existsById(subId)) {
            throw new ErrorException("Subject with id " + subId + " dont exist.");
        }
        Subject subject = new Subject();
        subject = subjectMapper.reqToSubj(subject, subjectRequest);
        subject.setId(subId);
        subjectDAO.save(subject);
        return subjectMapper.reqToRes(subjectRequest);
    }
}
