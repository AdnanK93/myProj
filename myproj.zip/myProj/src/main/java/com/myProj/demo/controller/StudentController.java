package com.myProj.demo.controller;

import com.myProj.demo.mapper.StudentMapper;
import com.myProj.demo.models.StudentRequest;
import com.myProj.demo.models.StudentResponse;
import com.myProj.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/student")
public class StudentController {
    @Autowired
    StudentService studentService;
    @Autowired
    StudentMapper studentMapper;

    @PostMapping(value = "/create-student")
    public StudentResponse create(@RequestBody StudentRequest studentRequest) {
        return studentService.create(studentRequest);
    }

    @DeleteMapping(value = "/{studId}")
    public String delete(@PathVariable int studId) {
        return studentService.delete(studId);
    }

    @GetMapping(value = "/{studId}")
    public StudentResponse find(@PathVariable int studId) {
        return studentService.getById(studId);
    }

    @PutMapping(value = "/{studId}")
    public StudentResponse update(@PathVariable int studId, @RequestBody StudentRequest studentRequest) {
        return studentService.update(studId, studentRequest);
    }
}
