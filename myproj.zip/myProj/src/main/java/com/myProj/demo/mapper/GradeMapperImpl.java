package com.myProj.demo.mapper;

import com.myProj.demo.entity.Grade;
import com.myProj.demo.models.GradeCreateReq;
import com.myProj.demo.models.GradeRequest;
import com.myProj.demo.models.GradeResponse;
import org.springframework.stereotype.Component;

@Component
public class GradeMapperImpl implements GradeMapper {
    @Override
    public Grade reqToGrade(Grade grade,GradeRequest gradeRequest) {
        grade.setStudentId(gradeRequest.getStudentId());
        grade.setSubjectId(gradeRequest.getSubjectId());
        grade.setValue(gradeRequest.getValue());
        return grade;
    }

    @Override
    public GradeResponse grToRes(Grade grade) {
        GradeResponse gradeResponse=new GradeResponse();
        gradeResponse.setId(grade.getId());
        gradeResponse.setStudentId(grade.getStudentId());
        gradeResponse.setSubjectId(grade.getSubjectId());
        gradeResponse.setValue(grade.getValue());
        return gradeResponse;
    }


}
