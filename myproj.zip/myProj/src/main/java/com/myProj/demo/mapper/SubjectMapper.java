package com.myProj.demo.mapper;

import com.myProj.demo.entity.Subject;
import com.myProj.demo.models.ProfessorResponse;
import com.myProj.demo.models.SubjectRequest;
import com.myProj.demo.models.SubjectResponse;

public interface SubjectMapper {
    Subject reqToSubj(Subject subject,SubjectRequest subjectRequest);

    SubjectResponse reqToRes(SubjectRequest subjectRequest);

    SubjectResponse subToRes(Subject subject);
}
