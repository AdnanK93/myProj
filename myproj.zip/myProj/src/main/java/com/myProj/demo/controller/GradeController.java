package com.myProj.demo.controller;

import com.myProj.demo.models.GradeCreateReq;
import com.myProj.demo.models.GradeRequest;
import com.myProj.demo.models.GradeResponse;
import com.myProj.demo.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/grade")
public class GradeController {
    @Autowired
    GradeService gradeService;
    @PostMapping(value = "/create-grade")
    public GradeResponse crate(@RequestBody GradeCreateReq gradeCreateReq){
        return gradeService.create(gradeCreateReq);
    }
    @GetMapping(value = "/{grId}")
    public GradeResponse getGr(@PathVariable int grId){
        return gradeService.getGr(grId);
    }
    @DeleteMapping(value = "/{grId}")
    public String delete(@PathVariable int grId){
        return gradeService.delete(grId);
    }
    @PutMapping(value = "/{grId}")
    public GradeResponse update(@PathVariable int grId,@RequestBody GradeRequest gradeRequest){
        return gradeService.update(grId,gradeRequest);
    }

}
