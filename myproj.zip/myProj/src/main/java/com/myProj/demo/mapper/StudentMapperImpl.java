package com.myProj.demo.mapper;

import com.myProj.demo.entity.Student;
import com.myProj.demo.models.StudentRequest;
import com.myProj.demo.models.StudentResponse;
import org.springframework.stereotype.Component;

@Component
public class StudentMapperImpl implements StudentMapper {
    @Override
    public StudentResponse reqToRes(StudentRequest studentRequest) {
        return new StudentResponse(studentRequest.getId(),studentRequest.getFirstName(),studentRequest.getLastName(),studentRequest.getEmail(),
                studentRequest.getGrades());
    }

    @Override
    public Student reqToStud(Student student,StudentRequest studentRequest) {
        if(studentRequest.getFirstName()!=null) student.setFirstName(studentRequest.getFirstName());
        if(studentRequest.getLastName()!=null) student.setLastName(studentRequest.getLastName());
        if(studentRequest.getEmail()!=null) student.setEmail(studentRequest.getEmail());
        if(studentRequest.getGrades()!=null) student.setGrades(studentRequest.getGrades());
        return student;
    }

    @Override
    public StudentResponse studToRes(Student student) {
        return new StudentResponse(student.getId(),student.getFirstName(),student.getLastName(),student.getEmail(),
                student.getGrades());
    }
}
