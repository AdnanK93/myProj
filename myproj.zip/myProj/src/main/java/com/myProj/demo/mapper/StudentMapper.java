package com.myProj.demo.mapper;

import com.myProj.demo.entity.Student;
import com.myProj.demo.models.StudentRequest;
import com.myProj.demo.models.StudentResponse;
import org.springframework.stereotype.Component;

@Component
public interface StudentMapper {
    StudentResponse reqToRes(StudentRequest studentRequest);
    Student reqToStud(Student student,StudentRequest studentRequest);
    StudentResponse studToRes(Student student);
}
