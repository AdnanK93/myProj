package com.myProj.demo.service;

import com.myProj.demo.Repository.ProfessorRep;
import com.myProj.demo.controller.ErrorException;
import com.myProj.demo.entity.Professor;
import com.myProj.demo.mapper.ProfessorMapper;
import com.myProj.demo.models.ProfessorRequest;
import com.myProj.demo.models.ProfessorResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfessorServiceImpl implements ProfessorService {

    @Autowired
    ProfessorRep professorDAO;
    @Autowired
    ProfessorMapper professorMapper;

    @Override
    public ProfessorResponse create(ProfessorRequest professorRequest) {
        //Professor professorEntity=null;
        Professor professorEntity = new Professor();

        professorEntity = professorMapper.dtoToEntity(professorEntity, professorRequest);
        Professor professor = professorDAO.save(professorEntity);
        return professorMapper.entityToDto(professor);
    }

    @Override
    public ProfessorResponse update(int profId, ProfessorRequest professorRequest) {
        if (!professorDAO.existsById(profId)) {
            throw new ErrorException("Professor dont exist");
        }
        Professor professor = new Professor();
        professor = professorMapper.dtoToEntity(professor, professorRequest);
        professor.setId(profId);
        professorDAO.save(professor);

        return professorMapper.toResponse(professorRequest);
    }

    @Override
    public boolean containsKeyProf(int profId) {
        return professorDAO.existsById(profId);
    }

    @Override
    public Professor getProfessor(int profId) {
        if(!professorDAO.existsById(profId)){
            throw new ErrorException("Profesor with id " + profId + " doesn't exist.");
        }
        return professorDAO.getOne(profId);
    }

    @Override
    public String delete(int profId) {
        if (professorDAO.existsById(profId)){
        professorDAO.deleteById(profId);
        return "Deleted professor " + profId;
        } else {
            return "Professor with id: " + profId + "doesn't exist.";
        }
    }
}
