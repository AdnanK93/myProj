package com.myProj.demo.mapper;

import com.myProj.demo.entity.Professor;
import com.myProj.demo.models.ProfessorRequest;
import com.myProj.demo.models.ProfessorResponse;
import org.springframework.stereotype.Component;

@Component
public class ProfessorMapperImpl implements ProfessorMapper {
    public ProfessorMapperImpl(){

    }
    @Override
    public ProfessorResponse toResponse(ProfessorRequest professorRequest) {
        ProfessorResponse professorResponse=new ProfessorResponse();
        professorResponse.setId(professorRequest.getId());
        professorResponse.setFirstName(professorRequest.getFirstName());
        professorResponse.setLastName(professorRequest.getLastName());
        professorResponse.setEmail(professorRequest.getEmail());
        professorResponse.setSubjects(professorRequest.getSubjects());
        return professorResponse;
    }
    @Override
    public ProfessorResponse entityToDto(Professor professorEntity) {
        ProfessorResponse professorResponse = new ProfessorResponse();
        professorResponse.setFirstName(professorEntity.getFirstName());
        professorResponse.setLastName(professorEntity.getLastName());
        professorResponse.setEmail(professorEntity.getEmail());
        professorResponse.setSubjects(professorEntity.getSubjects());
        return professorResponse;
    }
    @Override
    public Professor dtoToEntity(Professor professor, ProfessorRequest professorRequest){
        professor.setFirstName(professorRequest.getFirstName());
        professor.setLastName(professorRequest.getLastName());
        professor.setEmail(professorRequest.getEmail());
        professor.setSubjects(professorRequest.getSubjects());
        //Professor professor=new Professor("n","n","n@gmail.com");
        return professor;
    }
}
