package com.myProj.demo.service;

import com.myProj.demo.Repository.GradeRep;
import com.myProj.demo.Repository.ProfessorRep;
import com.myProj.demo.Repository.StudentRep;
import com.myProj.demo.Repository.SubjectRep;
import com.myProj.demo.controller.ErrorException;
import com.myProj.demo.entity.Grade;
import com.myProj.demo.entity.Professor;
import com.myProj.demo.entity.Student;
import com.myProj.demo.entity.Subject;
import com.myProj.demo.mapper.GradeMapper;
import com.myProj.demo.models.GradeCreateReq;
import com.myProj.demo.models.GradeRequest;
import com.myProj.demo.models.GradeResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GradeServiceImpl implements GradeService {
    @Autowired
    GradeRep gradeDAO;
    @Autowired
    SubjectRep subjectDAO;
    @Autowired
    StudentRep studentDAO;
    @Autowired
    GradeMapper gradeMapper;
    @Override
    public GradeResponse create(GradeCreateReq gradeCreateReq) {
        if(!subjectDAO.existsById(gradeCreateReq.getSubjectId())){
            throw new ErrorException("Subject with id " + gradeCreateReq.getSubjectId() + " dont exist.");
        }
        if(!studentDAO.existsById(gradeCreateReq.getStudentId())){
            throw new ErrorException("Student with id " + gradeCreateReq.getStudentId() + " dont exist.");
        }
        if (gradeCreateReq.getValue()>10 || gradeCreateReq.getValue()<6){
            throw new ErrorException("Set of values is {6,7,8,9,10}.");
        }
        Subject subject=subjectDAO.getOne(gradeCreateReq.getSubjectId());
        Student student=studentDAO.getOne(gradeCreateReq.getStudentId());
        Grade grade=new Grade();
        grade.setSubjectId(subject);
        grade.setStudentId(student);
        gradeDAO.save(grade);
        return gradeMapper.grToRes(grade);
    }

    @Override
    public GradeResponse getGr(int grId) {
        if(!gradeDAO.existsById(grId)){
            throw new ErrorException("Grade with id " + grId + " dont exist.");
        }
        Grade grade=gradeDAO.getOne(grId);
        return gradeMapper.grToRes(grade);
    }

    @Override
    public String delete(int grId) {
        if(!gradeDAO.existsById(grId)){
            throw new ErrorException("Grade with id " + grId + " dont exist.");
        }
        gradeDAO.deleteById(grId);
        return "Grade with id " + grId + " deleted.";
    }

    @Override
    public GradeResponse update(int grId, GradeRequest gradeRequest) {
        Grade grade=gradeDAO.getOne(grId);
        grade=gradeMapper.reqToGrade(grade,gradeRequest);
        grade.setId(grId);
        gradeDAO.save(grade);
        return gradeMapper.grToRes(grade);
    }
}
