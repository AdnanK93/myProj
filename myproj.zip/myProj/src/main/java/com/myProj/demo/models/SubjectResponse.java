package com.myProj.demo.models;

import com.myProj.demo.entity.Professor;

import java.io.Serializable;

public class SubjectResponse implements Serializable {
    private int id;
    private String name;
    private Professor professorId;
    public SubjectResponse(){

    }

    public SubjectResponse(String name) {
        this.name = name;
        this.professorId = professorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Professor getProfessorId() {
        return professorId;
    }

    public void setProfessorId(Professor professorId) {
        this.professorId = professorId;
    }
}
