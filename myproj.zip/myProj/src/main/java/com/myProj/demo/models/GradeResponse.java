package com.myProj.demo.models;

import com.myProj.demo.entity.Student;
import com.myProj.demo.entity.Subject;

import java.io.Serializable;

public class GradeResponse implements Serializable {
    private int id;
    private Student studentId;
    private Subject subjectId;
    private int value;
    public GradeResponse(){

    }

    public GradeResponse(Student studentId, Subject subjectId, int value) {
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Student getStudentId() {
        return studentId;
    }

    public void setStudentId(Student studentId) {
        this.studentId = studentId;
    }

    public Subject getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Subject subjectId) {
        this.subjectId = subjectId;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
