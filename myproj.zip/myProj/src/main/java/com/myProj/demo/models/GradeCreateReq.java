package com.myProj.demo.models;

public class GradeCreateReq {
    private int studentId;
    private int subjectId;
    private int value;
    public GradeCreateReq(){

    }

    public GradeCreateReq(int studentId, int subjectId, int value) {
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.value = value;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
