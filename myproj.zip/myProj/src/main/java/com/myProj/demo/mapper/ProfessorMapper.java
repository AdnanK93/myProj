package com.myProj.demo.mapper;

import com.myProj.demo.entity.Professor;
import com.myProj.demo.models.ProfessorRequest;
import com.myProj.demo.models.ProfessorResponse;

public interface ProfessorMapper {
    ProfessorResponse toResponse(ProfessorRequest professorRequest);
    ProfessorResponse entityToDto(Professor professorEntity);
    Professor dtoToEntity(Professor professor, ProfessorRequest professorRequest);
}
