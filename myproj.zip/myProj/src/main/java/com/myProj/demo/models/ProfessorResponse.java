package com.myProj.demo.models;


import com.myProj.demo.entity.Subject;


import java.io.Serializable;

import java.util.List;

public class ProfessorResponse implements Serializable {

    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private List<Subject> subjects;

    public ProfessorResponse() {
    }

    public ProfessorResponse(int id, String firstName, String lastName, String email, List<Subject> subjects) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.subjects = subjects;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ProfessorResponse{");
        sb.append("id=").append(id);
        sb.append(", firstName='").append(firstName).append('\'');
        sb.append(", lastName='").append(lastName).append('\'');
        sb.append(", email='").append(email).append('\'');
        sb.append(", subjects=").append(subjects);
        sb.append('}');
        return sb.toString();
    }
}
