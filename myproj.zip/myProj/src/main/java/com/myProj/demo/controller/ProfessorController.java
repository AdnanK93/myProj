package com.myProj.demo.controller;

import com.myProj.demo.entity.Professor;
import com.myProj.demo.models.ProfessorRequest;
import com.myProj.demo.models.ProfessorResponse;
import com.myProj.demo.service.ProfessorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/professor")
public class ProfessorController {

    @Autowired
    ProfessorService professorService;

    @PostMapping(value = "/create")
    ProfessorResponse create(@RequestBody ProfessorRequest professorRequest) {
        return professorService.create(professorRequest);
    }

    @PutMapping(value = "/{profId}")
    ProfessorResponse update(@PathVariable int profId, @RequestBody ProfessorRequest professorRequest) {
        return professorService.update(profId, professorRequest);
    }

    @GetMapping("/{profId}")
    public Professor find(@PathVariable int profId) {

        return professorService.getProfessor(profId);
    }

    @DeleteMapping(value = "/{profId}")
    public String delete(@PathVariable int profId) {

        return professorService.delete(profId);
    }
}
