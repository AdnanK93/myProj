package com.myProj.demo.service;

import com.myProj.demo.Repository.StudentRep;
import com.myProj.demo.controller.ErrorException;
import com.myProj.demo.entity.Student;
import com.myProj.demo.mapper.StudentMapper;
import com.myProj.demo.models.StudentRequest;
import com.myProj.demo.models.StudentResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    StudentRep studentDAO;
    @Autowired
    StudentMapper studentMapper;

    @Override
    public StudentResponse create(StudentRequest studentRequest) {
        Student studentEntity=new Student();
        studentDAO.save(studentMapper.reqToStud(studentEntity,studentRequest));
        return studentMapper.reqToRes(studentRequest);
    }

    @Override
    public String delete(int studId) {
        if(!studentDAO.existsById(studId)){
            throw new ErrorException("Student not found");
        }
        studentDAO.deleteById(studId);
        return "Deleted student " + studId;
    }

    @Override
    public boolean existById(int studId) {
        return studentDAO.existsById(studId);
    }

    @Override
    public StudentResponse getById(int studId) {
        Student student = studentDAO.getOne(studId);
        return studentMapper.studToRes(student);
    }

    @Override
    public StudentResponse update(int studId, StudentRequest studentRequest) {
        if(!studentDAO.existsById(studId)){
            throw new ErrorException("Student dont exist");
        }
        Student student=studentDAO.getOne(studId);
        student=studentMapper.reqToStud(student,studentRequest);
        student.setId(studId);
        student=studentDAO.save(student);
        return studentMapper.studToRes(student);
    }
}
