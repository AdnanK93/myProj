package com.myProj.demo.service;

import com.myProj.demo.entity.Professor;
import com.myProj.demo.models.ProfessorRequest;
import com.myProj.demo.models.ProfessorResponse;

public interface ProfessorService {
    ProfessorResponse create(ProfessorRequest professorRequest);

    boolean containsKeyProf(int profId);

    Professor getProfessor(int profId);

    String delete(int profId);

    ProfessorResponse update(int profId, ProfessorRequest professorRequest);
}
