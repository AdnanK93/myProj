package com.myProj.demo.service;

import com.myProj.demo.models.SubjectRequest;
import com.myProj.demo.models.SubjectResponse;

public interface SubjectService {
    SubjectResponse create(SubjectRequest subjectRequest);

    SubjectResponse getSub(int subId);

    SubjectResponse addPTosub(int subId, int profId);

    String delete(int subId);

    SubjectResponse update(int subId, SubjectRequest subjectRequest);
}
