package com.myProj.demo.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.myProj.demo.entity.Student;
import com.myProj.demo.entity.Subject;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;

public class GradeRequest implements Serializable {
    private int id;
    private Student studentId;
    private Subject subjectId;
    private int value;
    public GradeRequest(){

    }

    public GradeRequest(Student studentId, Subject subjectId, int value) {
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Student getStudentId() {
        return studentId;
    }

    public void setStudentId(Student studentId) {
        this.studentId = studentId;
    }

    public Subject getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(Subject subjectId) {
        this.subjectId = subjectId;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
