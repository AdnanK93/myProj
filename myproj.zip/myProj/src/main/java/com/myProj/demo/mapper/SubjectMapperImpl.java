package com.myProj.demo.mapper;

import com.myProj.demo.entity.Subject;
import com.myProj.demo.models.ProfessorResponse;
import com.myProj.demo.models.SubjectRequest;
import com.myProj.demo.models.SubjectResponse;
import org.springframework.stereotype.Component;

@Component
public class SubjectMapperImpl implements SubjectMapper {
    @Override
    public Subject reqToSubj(Subject subject,SubjectRequest subjectRequest) {
        subject.setName(subjectRequest.getName());
        return subject;
    }

    @Override
    public SubjectResponse reqToRes(SubjectRequest subjectRequest) {
        SubjectResponse subjectResponse=new SubjectResponse(subjectRequest.getName());
        subjectResponse.setProfessorId(subjectRequest.getProfessorId());
        return subjectResponse;
    }

    @Override
    public SubjectResponse subToRes(Subject subject) {
        SubjectResponse subjectResponse=new SubjectResponse();
        subjectResponse.setName(subject.getName());
        subjectResponse.setProfessorId(subject.getProfessorId());
        return subjectResponse;
    }
}
