package com.myProj.demo.mapper;

import com.myProj.demo.entity.Grade;
import com.myProj.demo.models.GradeCreateReq;
import com.myProj.demo.models.GradeRequest;
import com.myProj.demo.models.GradeResponse;

public interface GradeMapper {
    Grade reqToGrade(Grade grade,GradeRequest gradeRequest);
    GradeResponse grToRes(Grade grade);
}
